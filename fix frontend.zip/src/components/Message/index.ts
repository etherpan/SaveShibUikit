export { default as Message } from "./Message";
export type { MessageProps } from "./types";
