export type TooltipTheme = {
  background: string;
  text: string;
  boxShadow: string;
};
